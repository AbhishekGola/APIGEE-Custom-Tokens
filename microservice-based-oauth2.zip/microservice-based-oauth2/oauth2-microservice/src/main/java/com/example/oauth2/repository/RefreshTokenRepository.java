@Repository
public interface RefreshTokenRepository extends CassandraRepository<RefreshToken, String> { }

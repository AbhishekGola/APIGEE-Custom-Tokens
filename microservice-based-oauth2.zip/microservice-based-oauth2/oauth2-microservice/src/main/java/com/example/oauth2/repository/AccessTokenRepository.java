@Repository
public interface AccessTokenRepository extends CassandraRepository<AccessToken, String> { }

// RaiseInvalidToken.js - Sets error variables for invalid token
print('Starting RaiseInvalidToken.js execution');
context.setVariable('token.valid', false);
context.setVariable('token.error', 'The access token is invalid or expired.');
print('Checking for invalid token condition...');
// RaiseInvalidToken.js - Sets error variables for invalid token
context.setVariable('token.valid', false);
context.setVariable('token.error', 'The access token is invalid or expired.');
print('Invalid token raised if condition met');
